<?php
require_once __DIR__ . '/includes/bootstrap.php';
$student = require_viewer();

$total = (int) $pdo->query("SELECT COUNT(*) FROM research WHERE status='approved'")->fetchColumn();

$categories = $pdo->query("
    SELECT c.category_id, c.category_name, c.description, COUNT(r.research_id) AS total
      FROM categories c
      LEFT JOIN research r ON r.category_id = c.category_id AND r.status = 'approved'
     GROUP BY c.category_id, c.category_name, c.description
     ORDER BY c.category_name
")->fetchAll();

$recent = $pdo->query("
    SELECT r.research_id, r.title, r.year, r.published_date, r.abstract,
           (r.file_path IS NOT NULL AND r.file_path <> '') AS has_file,
           c.category_name,
           (SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
              FROM research_authors ra JOIN authors a ON a.author_id = ra.author_id
             WHERE ra.research_id = r.research_id) researchers
      FROM research r
      JOIN categories c ON c.category_id = r.category_id
     WHERE r.status = 'approved'
     ORDER BY r.published_date DESC, r.research_id DESC
     LIMIT 6
")->fetchAll();

$subscription = $student ? get_active_subscription($pdo, (int) $student['student_id']) : null;
$plans = $student ? get_plans($pdo) : [];

$pageTitle = 'Home';
require __DIR__ . '/includes/header.php';
?>

<section class="student-hero">
    <div class="container hero-layout">
        <div class="hero-copy">
            <p class="hero-eyebrow">Isabela State University &middot; Digital Research Repository</p>
            <h1>Find the research that came before yours</h1>
            <p>Search approved Information Technology theses and research works. Read abstracts for free; unlock full manuscripts with a Research Access plan.</p>

            <form class="search-bar live-search-form" action="<?= BASE_URL ?>research.php" method="get" autocomplete="off">
                <div class="suggest-wrap">
                    <input class="form-control live-search" type="search" name="q" placeholder="Search title, abstract, author, keyword..." aria-label="Search research" data-suggest-url="<?= BASE_URL ?>suggestions.php">
                    <div class="suggestions" hidden></div>
                </div>
                <button class="btn btn-primary" type="submit">Search</button>
            </form>
            <p class="hero-small"><?= $total ?> approved research record<?= $total === 1 ? '' : 's' ?> in the archive.</p>
        </div>
        <figure class="hero-visual">
            <img src="<?= BASE_URL ?>assets/images/isu.jpg" alt="Isabela State University campus sign">
            <figcaption>
                <span class="hero-visual-mark" aria-hidden="true">&#10003;</span>
                <span><strong>Research starts here</strong><small>Explore work from the ISU community</small></span>
            </figcaption>
        </figure>
    </div>
</section>

<?php if ($student): ?>
<section class="container section pt-0" id="access-plans">
    <header class="page-head">
        <h2>Subscription</h2>
        <p>Choose a plan below to subscribe.</p>
    </header>
    <?php require __DIR__ . '/includes/plan-options.php'; ?>
</section>
<?php endif; ?>

<section class="container section">
    <div class="section-head">
        <div>
            <p class="eyebrow">Explore the archive</p>
            <h2>Browse by category</h2>
        </div>
    </div>
    <?php if ($categories): ?>
        <div class="row g-3">
            <?php foreach ($categories as $category): ?>
                <div class="col-md-6">
                    <a class="category-tile" href="<?= BASE_URL ?>research.php?category=<?= (int) $category['category_id'] ?>">
                        <strong><?= e($category['category_name']) ?></strong>
                        <?php if (!empty($category['description'])): ?><p><?= e($category['description']) ?></p><?php endif; ?>
                        <span><?= (int) $category['total'] ?> research record<?= (int) $category['total'] === 1 ? '' : 's' ?> &rarr;</span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-muted mb-0">No research categories are available yet.</p>
    <?php endif; ?>
</section>

<section class="container section">
    <div class="section-head">
        <div>
            <p class="eyebrow">The latest additions</p>
            <h2>Recently added</h2>
        </div>
        <a href="<?= BASE_URL ?>research.php">View all research</a>
    </div>
    <?php if (!$recent): ?>
        <div class="empty-state"><h2>No approved research yet.</h2><p>Check back soon.</p></div>
    <?php else: ?>
        <div class="row g-3">
            <?php foreach ($recent as $r): ?>
                <div class="col-md-6 col-lg-4"><?php include __DIR__ . '/includes/research-card.php'; ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
