<?php
require_once __DIR__ . '/includes/bootstrap.php';
$student = require_student();

$subscription = get_active_subscription($pdo, (int) $student['student_id']);
$history      = get_student_subscriptions($pdo, (int) $student['student_id']);

$pageTitle = 'Profile';
require __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <a class="back-link" href="<?= BASE_URL ?>index.php">&larr; Back to home</a>

    <header class="page-head">
        <p class="eyebrow">Your account</p>
        <h1>Profile</h1>
    </header>

    <div class="row g-4">
        <div class="col-lg-7">
            <section class="panel">
                <h2 class="panel-title">Account details</h2>
                <dl class="profile-grid">
                    <div><dt>Full name</dt><dd><?= e($student['full_name']) ?></dd></div>
                    <div><dt>Email</dt><dd><?= e($student['email']) ?></dd></div>
                    <div><dt>Student ID</dt><dd><?= e($student['student_number']) ?></dd></div>
                    <div><dt>User type</dt><dd><?= e(user_type_label($student['user_type'])) ?></dd></div>
                    <div><dt>Program</dt><dd><?= e($student['program_name'] ?? 'Information Technology') ?></dd></div>
                    <div><dt>Account status</dt><dd><?= status_badge($student['status']) ?></dd></div>
                </dl>
            </section>
        </div>

        <div class="col-lg-5">
            <section class="panel">
                <h2 class="panel-title">Access plan</h2>
                <?php if ($subscription): ?>
                    <p class="plan-now"><?= e($subscription['plan_name']) ?> <?= status_badge('active') ?></p>
                    <p class="text-muted mb-1">Full manuscripts unlocked.</p>
                    <p class="mb-3"><strong>Expires:</strong> <?= e(format_datetime($subscription['expiration_date'])) ?></p>
                    <a class="btn btn-outline-primary btn-sm" href="<?= BASE_URL ?>index.php#access-plans">Extend plan</a>
                <?php else: ?>
                    <p class="plan-now">Free Access</p>
                    <p class="text-muted">You can browse and read abstracts. Get a Research Access plan to read full manuscripts.</p>
                    <a class="btn btn-primary btn-sm" href="<?= BASE_URL ?>index.php#access-plans">View Access Plans</a>
                <?php endif; ?>
            </section>
        </div>
    </div>

    <section class="panel mt-4">
        <h2 class="panel-title">Subscription history</h2>
        <?php if (!$history): ?>
            <p class="empty-note">No subscriptions yet.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table align-middle sv-table">
                    <thead><tr><th>Plan</th><th>Reference</th><th>Status</th><th>Start</th><th>Expires</th></tr></thead>
                    <tbody>
                    <?php foreach ($history as $h): ?>
                        <tr>
                            <td><?= e($h['plan_name']) ?></td>
                            <td class="mono"><?= e($h['reference_code']) ?></td>
                            <td><?= status_badge($h['status']) ?></td>
                            <td class="text-nowrap"><?= e(format_date($h['start_date'])) ?></td>
                            <td class="text-nowrap"><?= e(format_date($h['expiration_date'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
