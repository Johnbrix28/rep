<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_student_logged_in()) {
    redirect(BASE_URL . 'index.php');
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Your session expired. Please try again.';
    } else {
        $email    = normalize_email($_POST['email'] ?? '');
        $password = (string) ($_POST['password'] ?? '');

        $result = authenticate_student($pdo, $email, $password);

        if ($result['ok']) {
            login_student($result['student']);
            log_student_activity($pdo, (int) $result['student']['student_id'], 'Student signed in');
            set_flash('success', 'Welcome to Study Vault, ' . $result['student']['full_name'] . '!');
            redirect(BASE_URL . 'index.php');
        }
        $error = $result['error'];
    }
}
$pageTitle = 'Login';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login &middot; Study Vault</title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/isu-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>
<body class="auth-page">
<div class="auth-wrap">
    <div class="auth-card">
        <div class="login-brand">
            <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="">
            <div><strong>Study Vault</strong><span>Thesis and Research System</span></div>
        </div>

        <h1>Welcome back</h1>
        <p class="login-sub">Log in with your email address to search and read the IT research repository.</p>

        <?php render_flashes(); ?>
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" data-validate novalidate>
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label" for="email">Email address</label>
                <input class="form-control" type="email" id="email" name="email" required autofocus
                       autocomplete="username" placeholder="you@example.com" value="<?= e($email) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label" for="password">Password</label>
                <input class="form-control" type="password" id="password" name="password" required autocomplete="current-password">
            </div>
            <button class="btn btn-primary w-100" type="submit">Log in</button>
        </form>

        <p class="auth-switch">First time here? <a href="<?= BASE_URL ?>verify.php">Verify your Student ID</a></p>
        <a class="login-back" href="<?= BASE_URL ?>admin/login.php">Administrator login</a>
    </div>
</div>
</body>
</html>
