<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_viewer();

$cats = $pdo->query("
    SELECT c.category_id, c.category_name, c.description, COUNT(r.research_id) total
      FROM categories c
      LEFT JOIN research r ON r.category_id = c.category_id AND r.status = 'approved'
     GROUP BY c.category_id, c.category_name, c.description
     ORDER BY c.category_name
")->fetchAll();

$pageTitle = 'Categories';
require __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <a class="back-link" href="<?= BASE_URL ?>research.php">&larr; Back to research</a>

    <header class="page-head">
        <p class="eyebrow">Research archive</p>
        <h1>Categories</h1>
        <p>Browse approved research by IT major area.</p>
    </header>

    <div class="row g-3">
        <?php foreach ($cats as $c): ?>
            <div class="col-md-6">
                <a class="category-tile category-tile-lg" href="<?= BASE_URL ?>research.php?category=<?= (int) $c['category_id'] ?>">
                    <strong><?= e($c['category_name']) ?></strong>
                    <p><?= e($c['description'] ?? '') ?></p>
                    <span><?= (int) $c['total'] ?> research record<?= (int) $c['total'] === 1 ? '' : 's' ?> &rarr;</span>
                </a>
            </div>
        <?php endforeach; ?>
        <?php if (!$cats): ?>
            <div class="empty-state"><h2>No categories yet.</h2></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
