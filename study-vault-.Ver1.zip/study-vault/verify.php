<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_student_logged_in()) {
    redirect(BASE_URL . 'index.php');
}

$error     = '';
$errors    = [];
$showLogin = false;      // show a "Log in" button next to the error
$studentId = '';

// The current step lives on the SERVER (session). The browser cannot jump ahead.
$step   = verify_current_step();
$state  = verify_state();
$record = null;

if ($step > 1) {
    $record = get_school_record($pdo, (int) $state['record_id']);
    if (!$record) {
        verify_state_clear();
        $step = 1;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');

    if (!csrf_valid()) {
        $error = 'Your session expired. Please try again.';
    } elseif ($action === 'restart') {
        verify_state_clear();
        redirect(BASE_URL . 'verify.php');

    /* ---------- STEP 1: Student ID -> send code ---------- */
    } elseif ($action === 'send_code') {
        $studentId = normalize_student_id($_POST['student_id'] ?? '');

        if (verify_lookup_throttled($pdo)) {
            $error = 'Too many attempts. Please wait ' . LOGIN_WINDOW_MINUTES . ' minutes and try again.';
        } elseif (!valid_student_id_format($studentId)) {
            $error = 'Enter a valid Student ID (for example 24-01048).';
        } else {
            $rec = find_school_record($pdo, $studentId);

            if (!$rec) {
                verify_lookup_failed($pdo);
                $error = 'Student ID not found in the school database.';
            } elseif (!school_record_eligibility($rec)['ok']) {
                verify_lookup_failed($pdo);
                $error = 'Not eligible for Study Vault. Only enrolled students and alumni of the IT programs can register.';
            } else {
                $acct = school_record_account_state($pdo, $rec);

                if ($acct['state'] === 'linked') {
                    $error = 'This Student ID is already linked to an account. Please log in.';
                    $showLogin = true;
                } elseif ($acct['state'] === 'email_taken') {
                    $error = 'The school email address for this Student ID is already used by another account. Please contact the administrator.';
                } elseif (verification_hourly_limit_reached($pdo, (int) $rec['id'])) {
                    $error = 'Too many codes were requested for this Student ID. Please try again in an hour.';
                } elseif (($wait = verification_resend_wait($pdo, (int) $rec['id'])) > 0) {
                    $error = 'A code was just sent. Please wait ' . $wait . ' seconds before requesting another one.';
                } else {
                    $sent = issue_and_send_code($pdo, $rec);
                    if ($sent['ok']) {
                        verify_state_set(['record_id' => (int) $rec['id'], 'sent_at' => time()]);
                        log_student_activity($pdo, null, 'Verification code sent for Student ID ' . $rec['student_id']);
                        set_flash('success', 'A 6-digit verification code was sent to ' . mask_email((string) $rec['email']) . '. It expires in ' . VERIFY_CODE_TTL_MINUTES . ' minutes.');
                        redirect(BASE_URL . 'verify.php');
                    }
                    $error = $sent['error'];
                }
            }
        }

    /* ---------- STEP 2: resend / verify code ---------- */
    } elseif ($action === 'resend' && $step === 2 && $record) {
        if (verification_hourly_limit_reached($pdo, (int) $record['id'])) {
            $error = 'Too many codes were requested for this Student ID. Please try again in an hour.';
        } elseif (($wait = verification_resend_wait($pdo, (int) $record['id'])) > 0) {
            $error = 'Please wait ' . $wait . ' seconds before requesting another code.';
        } else {
            $sent = issue_and_send_code($pdo, $record);
            if ($sent['ok']) {
                verify_state_set(['record_id' => (int) $record['id'], 'sent_at' => time()]);
                set_flash('success', 'A new code was sent to ' . mask_email((string) $record['email']) . '. Earlier codes no longer work.');
                redirect(BASE_URL . 'verify.php');
            }
            $error = $sent['error'];
        }

    } elseif ($action === 'verify_code' && $step === 2 && $record) {
        $result = check_verification_code($pdo, (int) $record['id'], (string) ($_POST['code'] ?? ''));

        if ($result['ok']) {
            session_regenerate_id(true);
            verify_state_set(['record_id' => (int) $record['id'], 'verified_at' => time()]);
            set_flash('success', 'Email verified. Now create your password.');
            redirect(BASE_URL . 'verify.php');
        }
        $error = $result['error'];

    /* ---------- STEP 3: create password ---------- */
    } elseif ($action === 'create_account' && $step === 3 && $record) {
        $result = create_verified_account(
            $pdo,
            (int) $record['id'],
            (string) ($_POST['password'] ?? ''),
            (string) ($_POST['confirm_password'] ?? '')
        );

        if ($result['ok']) {
            verify_state_clear();
            set_flash('success', 'Your account was created. Log in with ' . mask_email((string) $record['email']) . ' and your new password.');
            redirect(BASE_URL . 'login.php');
        }
        $errors = $result['errors'];
        if (!empty($errors['general'])) {
            $error = $errors['general'];
            $showLogin = stripos($error, 'log in') !== false;
        }
    } else {
        $error = 'That action is not available right now.';
    }

    // The state may have changed while handling the request (e.g. a code was voided).
    $step = verify_current_step();
    if ($step > 1 && !$record) {
        $record = get_school_record($pdo, (int) (verify_state()['record_id'] ?? 0));
    }
}

$resendWait = ($step === 2 && $record) ? verification_resend_wait($pdo, (int) $record['id']) : 0;
$pageTitle  = 'Verify your Student ID';

function verify_field_error(array $errors, string $key): string
{
    return isset($errors[$key]) ? '<div class="invalid-feedback d-block">' . e($errors[$key]) . '</div>' : '';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Verify your Student ID &middot; Study Vault</title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/isu-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
    <style>
        .verify-steps{display:flex;gap:.5rem;margin:0 0 1.25rem;padding:0;list-style:none}
        .verify-steps li{flex:1;text-align:center;font-size:.78rem;padding:.4rem .25rem;border-radius:8px;background:#eef3ef;color:#6b7d72}
        .verify-steps li.done{background:#d6ecdc;color:#1f6b3a}
        .verify-steps li.active{background:#1f6b3a;color:#fff;font-weight:600}
        .code-input{font-size:1.6rem;letter-spacing:.5rem;text-align:center;font-family:Consolas,Menlo,monospace}
    </style>
</head>
<body class="auth-page">
<div class="auth-wrap">
    <div class="auth-card">
        <div class="login-brand">
            <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="">
            <div><strong>Study Vault</strong><span>Thesis and Research System</span></div>
        </div>

        <ol class="verify-steps" aria-label="Progress">
            <li class="<?= $step > 1 ? 'done' : 'active' ?>">1. Student ID</li>
            <li class="<?= $step > 2 ? 'done' : ($step === 2 ? 'active' : '') ?>">2. Code</li>
            <li class="<?= $step === 3 ? 'active' : '' ?>">3. Password</li>
        </ol>

        <?php render_flashes(); ?>
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?= e($error) ?>
                <?php if ($showLogin): ?>
                    <div class="mt-2"><a class="btn btn-sm btn-primary" href="<?= BASE_URL ?>login.php">Go to login</a></div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if ($step === 1): ?>
            <h1>Verify your Student ID</h1>
            <p class="login-sub">Enter your Student ID. We will email a 6-digit code to the address the school has on file for you.</p>

            <form method="post" novalidate>
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="send_code">
                <div class="mb-3">
                    <label class="form-label" for="student_id">Student ID</label>
                    <input class="form-control" id="student_id" name="student_id" required autofocus maxlength="50"
                           autocomplete="off" placeholder="e.g. 24-01048" value="<?= e($studentId) ?>">
                </div>
                <button class="btn btn-primary w-100" type="submit">Send Code</button>
            </form>

        <?php elseif ($step === 2 && $record): ?>
            <h1>Enter your code</h1>
            <p class="login-sub">We sent a 6-digit code to <strong><?= e(mask_email((string) $record['email'])) ?></strong>. It expires in <?= (int) VERIFY_CODE_TTL_MINUTES ?> minutes.</p>

            <form method="post" novalidate>
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="verify_code">
                <div class="mb-3">
                    <label class="form-label" for="code">6-digit code</label>
                    <input class="form-control code-input" id="code" name="code" required autofocus maxlength="6"
                           inputmode="numeric" pattern="[0-9]{6}" autocomplete="one-time-code" placeholder="••••••">
                </div>
                <button class="btn btn-primary w-100" type="submit">Verify Code</button>
            </form>

            <div class="d-flex justify-content-between align-items-center mt-3">
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="resend">
                    <button class="btn btn-link p-0" id="resendBtn" type="submit" <?= $resendWait > 0 ? 'disabled' : '' ?>
                            data-wait="<?= (int) $resendWait ?>">Resend code<?= $resendWait > 0 ? ' (' . (int) $resendWait . 's)' : '' ?></button>
                </form>
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="restart">
                    <button class="btn btn-link p-0 text-secondary" type="submit">Use a different Student ID</button>
                </form>
            </div>

        <?php elseif ($step === 3 && $record): ?>
            <h1>Welcome, <?= e($record['full_name']) ?>!</h1>
            <p class="login-sub">Create a password for your account. You will log in with <strong><?= e(mask_email((string) $record['email'])) ?></strong>.</p>

            <form method="post" novalidate>
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="create_account">
                <div class="mb-3">
                    <label class="form-label" for="password">Password</label>
                    <input class="form-control<?= isset($errors['password']) ? ' is-invalid' : '' ?>" type="password" id="password" name="password"
                           required autofocus autocomplete="new-password" minlength="<?= (int) PASSWORD_MIN_LENGTH ?>">
                    <div class="form-text">At least <?= (int) PASSWORD_MIN_LENGTH ?> characters, with a letter and a number.</div>
                    <?= verify_field_error($errors, 'password') ?>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="confirm_password">Confirm password</label>
                    <input class="form-control<?= isset($errors['confirm_password']) ? ' is-invalid' : '' ?>" type="password" id="confirm_password" name="confirm_password"
                           required autocomplete="new-password">
                    <?= verify_field_error($errors, 'confirm_password') ?>
                </div>
                <button class="btn btn-primary w-100" type="submit">Create Account</button>
            </form>
        <?php endif; ?>

        <p class="auth-switch">Already have an account? <a href="<?= BASE_URL ?>login.php">Log in</a></p>
    </div>
</div>
<script>
(function () {
    var b = document.getElementById('resendBtn');
    if (!b) return;
    var w = parseInt(b.getAttribute('data-wait'), 10) || 0;
    if (w <= 0) return;
    var t = setInterval(function () {
        w--;
        if (w <= 0) { clearInterval(t); b.disabled = false; b.textContent = 'Resend code'; }
        else { b.textContent = 'Resend code (' + w + 's)'; }
    }, 1000);
})();
</script>
</body>
</html>
