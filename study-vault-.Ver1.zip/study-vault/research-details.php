<?php
require_once __DIR__ . '/includes/bootstrap.php';

$student = require_viewer();          // approved student, or null for an administrator
$isAdmin = ($student === null);

$id = valid_id($_GET['id'] ?? null);
$backUrl = BASE_URL . ($isAdmin ? 'admin/research-database.php' : 'research.php');
if (!$id) {
    redirect($backUrl);
}

$stmt = $pdo->prepare('SELECT r.*, c.category_name, p.program_name
                         FROM research r
                         JOIN categories c ON c.category_id = r.category_id
                         LEFT JOIN programs p ON p.program_id = r.program_id
                        WHERE r.research_id = ?');
$stmt->execute([$id]);
$record = $stmt->fetch();

// Students can only ever see APPROVED research. Anything else looks like "not found".
if (!$record || (!$isAdmin && $record['status'] !== 'approved')) {
    set_flash('warning', 'Research record not found.');
    redirect($backUrl);
}

$authors = get_research_authors($pdo, $id);
$access  = check_manuscript_access($pdo, $record, $student, $isAdmin);
$hasFile = research_file_exists($record['file_path']);
$subscription = $student ? get_active_subscription($pdo, (int) $student['student_id']) : null;

if (!$isAdmin) {
    $pdo->prepare('UPDATE research SET view_count = view_count + 1 WHERE research_id = ?')->execute([$id]);
}

$relatedStmt = $pdo->prepare("SELECT research_id, title, year FROM research
                               WHERE category_id = ? AND research_id <> ? AND status = 'approved'
                               ORDER BY published_date DESC LIMIT 4");
$relatedStmt->execute([$record['category_id'], $id]);
$related = $relatedStmt->fetchAll();

$pageTitle = $record['title'];
require __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <a class="back-link" href="<?= e($backUrl) ?>">&larr; Back to research</a>

    <div class="record-layout">
        <article class="record-main">
            <p class="record-meta">
                <?= e($record['category_name']) ?> &middot; <?= e($record['year']) ?>
                <?php if ($isAdmin): ?> &middot; <?= status_badge($record['status']) ?><?php endif; ?>
            </p>
            <h1 class="record-title"><?= e($record['title']) ?></h1>

            <dl class="info-grid">
                <div><dt>Authors</dt><dd><?= e($authors ? implode(', ', $authors) : 'Not recorded') ?></dd></div>
                <div><dt>Category</dt><dd><?= e($record['category_name']) ?></dd></div>
                <div><dt>Year</dt><dd><?= e($record['year']) ?></dd></div>
                <div><dt>Program</dt><dd><?= e($record['program_name'] ?? 'Information Technology') ?></dd></div>
                <div><dt>Date published</dt><dd><?= e(format_date($record['published_date'])) ?></dd></div>
            </dl>

            <h2 class="record-heading">Abstract</h2>
            <div class="record-abstract">
                <?= trim((string) $record['abstract']) !== '' ? nl2br(e($record['abstract'])) : '<p class="text-muted">No abstract was recorded.</p>' ?>
            </div>

            <?php if ($tags = keyword_list($record['keywords'])): ?>
                <h2 class="record-heading">Keywords</h2>
                <ul class="tag-list">
                    <?php foreach ($tags as $tag): ?><li><?= e($tag) ?></li><?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </article>

        <aside class="access-panel">
            <h2 class="record-heading mt-0">Access</h2>

            <ul class="access-list">
                <li class="ok"><span class="dot"></span> Abstract available</li>
                <?php if (!$hasFile): ?>
                    <li class="off"><span class="dot"></span> No manuscript uploaded</li>
                <?php elseif ($access['allowed']): ?>
                    <li class="ok"><span class="dot"></span> Full manuscript available</li>
                    <li class="ok"><span class="dot"></span> Protected Viewer</li>
                <?php else: ?>
                    <li class="off"><span class="dot"></span> Full manuscript locked</li>
                <?php endif; ?>
            </ul>

            <?php if ($hasFile && $access['allowed']): ?>
                <a class="btn btn-primary w-100" href="<?= e(manuscript_viewer_url($id)) ?>">Open protected viewer</a>
                <p class="access-note">
                    <?= $isAdmin
                        ? 'Administrator access.'
                        : 'Your plan: <strong>' . e($subscription['plan_name'] ?? '') . '</strong> &middot; until ' . e(format_date($subscription['expiration_date'] ?? null)) ?>
                </p>
            <?php elseif ($hasFile): ?>
                <div class="lock-box">
                    <h3>Full Manuscript Access Required</h3>
                    <p>You can read the abstract and research information for free. An active Research Access plan is required to view the complete manuscript.</p>
                    <a class="btn btn-primary w-100" href="<?= BASE_URL ?>index.php#access-plans">View Access Plans</a>
                </div>
            <?php else: ?>
                <p class="access-note">A full manuscript has not been uploaded for this record yet.</p>
            <?php endif; ?>
        </aside>
    </div>

    <?php if ($related): ?>
        <section class="related">
            <h2>More research in this category</h2>
            <ul class="related-list">
                <?php foreach ($related as $item): ?>
                    <li>
                        <a href="<?= BASE_URL ?>research-details.php?id=<?= (int) $item['research_id'] ?>"><?= e($item['title']) ?></a>
                        <span><?= e($item['year']) ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
