<?php
$pageTitle  = $pageTitle ?? SITE_NAME;
$isStudent  = is_student_logged_in();
$isAdminView = !$isStudent && is_logged_in();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= e($pageTitle) ?> &middot; <?= e(SITE_NAME) ?></title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/isu-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>
<body class="student-body">
    <a class="skip-link" href="#main">Skip to content</a>

    <header class="site-header">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="<?= BASE_URL ?>index.php">
                    <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="" class="brand-mark">
                    <span class="brand-text">
                        <strong>Study Vault</strong>
                        <small>Thesis and Research System</small>
                    </span>
                </a>
                <div class="ms-auto d-flex align-items-center gap-2">
                    <?php if ($isStudent): ?>
                        <a class="profile-icon-link" href="<?= BASE_URL ?>profile.php" aria-label="Profile" title="Profile">
                            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <path d="M12 12a4.25 4.25 0 1 0 0-8.5A4.25 4.25 0 0 0 12 12Zm0 2c-4.1 0-7.5 2.1-7.5 4.75V21h15v-2.25C19.5 16.1 16.1 14 12 14Z"/>
                            </svg>
                        </a>
                        <a class="btn btn-sm btn-logout" href="<?= BASE_URL ?>logout.php">Logout</a>
                    <?php elseif ($isAdminView): ?>
                        <a class="btn btn-sm btn-logout" href="<?= BASE_URL ?>admin/logout.php">Logout</a>
                    <?php else: ?>
                        <a class="btn btn-sm btn-logout" href="<?= BASE_URL ?>login.php">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <main id="main">
        <div class="container flash-area">
            <?php render_flashes(); ?>
        </div>
