    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-brand">Study Vault</div>
            <p class="footer-note">A digital research repository for Information Technology students and alumni. Research records are reviewed and approved by administrators before they are published.</p>
            <p class="footer-legal">&copy; <?= date('Y') ?> Study Vault. Academic project build &middot; payments are a prototype only.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
