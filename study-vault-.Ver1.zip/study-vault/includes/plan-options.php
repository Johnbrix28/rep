<div class="row g-4 justify-content-center">
    <?php foreach ($plans as $plan): ?>
        <?php
        $isFree    = (int) $plan['full_access'] === 0 || (float) $plan['price'] <= 0;
        $isCurrent = $subscription && (int) $subscription['plan_id'] === (int) $plan['plan_id'];
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="plan-card <?= $isCurrent ? 'is-current' : '' ?> <?= (int) $plan['sort_order'] === 2 ? 'is-featured' : '' ?>">
                <?php if ($isCurrent): ?><span class="plan-ribbon">Current plan</span><?php endif; ?>
                <h2><?= e($plan['plan_name']) ?></h2>
                <p class="plan-price">
                    <?= e(format_price($plan['price'])) ?>
                    <?php if (!$isFree): ?><small>/ <?= (int) $plan['duration_days'] ?> days</small><?php endif; ?>
                </p>
                <p class="plan-desc"><?= e($plan['description']) ?></p>
                <ul class="plan-features">
                    <li>Browse approved research</li>
                    <li>Search by title, author, keyword and more</li>
                    <li>Read abstracts and research details</li>
                    <?php if (!$isFree): ?>
                        <li class="strong">Full manuscript viewing</li>
                        <li class="strong"><?= (int) $plan['duration_days'] ?> days of access</li>
                    <?php else: ?>
                        <li class="muted">Full manuscripts not included</li>
                    <?php endif; ?>
                </ul>
                <?php if ($isFree): ?>
                    <span class="btn btn-outline-secondary w-100 disabled"><?= $subscription ? 'Included with every account' : 'Your current plan' ?></span>
                <?php else: ?>
                    <a class="btn btn-primary w-100" href="<?= BASE_URL ?>checkout.php?plan=<?= (int) $plan['plan_id'] ?>">
                        <?= $subscription ? 'Extend with this plan' : 'Get this plan' ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>
