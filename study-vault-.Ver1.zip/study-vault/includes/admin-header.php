<?php
$pageTitle  = $pageTitle ?? 'Administrator';
$currentNav = basename($_SERVER['PHP_SELF']);
$admin      = current_admin();

// file => [label, [files that keep this item highlighted]]
$adminNav = [
    'dashboard.php'         => ['Dashboard',     ['dashboard.php']],
    'research-database.php' => ['Research',      ['research-database.php', 'research-add.php', 'research-edit.php', 'research-delete.php']],
    'students.php'          => ['Students',      ['students.php']],
    'school-records.php'    => ['School Records', ['school-records.php']],
    'categories.php'        => ['Categories',    ['categories.php']],
    'subscriptions.php'     => ['Subscriptions', ['subscriptions.php']],
    'activity-logs.php'     => ['Activity Logs', ['activity-logs.php']],
    'settings.php'          => ['Settings',      ['settings.php']],
];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= e($pageTitle) ?> &middot; Study Vault Admin</title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/isu-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>
<body class="admin-body">
    <nav class="admin-topbar">
        <div class="d-flex align-items-center gap-2">
            <button class="btn btn-sm btn-menu d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#adminSidebar" aria-label="Open menu">&#9776;</button>
            <a class="admin-brand" href="<?= BASE_URL ?>admin/dashboard.php">
                <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="" class="admin-brand-mark">
                <span class="admin-brand-name">Study Vault <small>Admin</small></span>
            </a>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="admin-who d-none d-md-inline">Hi, <?= e($admin['name'] ?: 'Administrator') ?></span>
            <a class="btn btn-sm btn-ghost" href="<?= BASE_URL ?>index.php">Student Site</a>
            <a class="btn btn-sm btn-ghost" href="<?= BASE_URL ?>admin/logout.php">Logout</a>
        </div>
    </nav>

    <div class="admin-shell">
        <aside class="offcanvas-lg offcanvas-start admin-sidebar" tabindex="-1" id="adminSidebar">
            <div class="offcanvas-header">
                <h2 class="h6 mb-0">Admin Menu</h2>
                <button class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <ul class="admin-menu">
                    <?php foreach ($adminNav as $file => [$label, $matches]): ?>
                        <li><a class="<?= in_array($currentNav, $matches, true) ? 'active' : '' ?>" href="<?= BASE_URL ?>admin/<?= e($file) ?>"><?= e($label) ?></a></li>
                    <?php endforeach; ?>
                    <li class="admin-menu-logout"><a href="<?= BASE_URL ?>admin/logout.php">Logout</a></li>
                </ul>
            </div>
        </aside>

        <main class="admin-main" id="admin-main">
            <?php render_flashes(); ?>
