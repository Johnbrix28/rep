<?php
/** Renders one research card. Expects $r (row with category_name, researchers). */
?>
<article class="research-card">
    <p class="card-meta"><span><?= e($r['category_name']) ?></span><span><?= e($r['year']) ?></span></p>
    <h3 class="card-title">
        <a href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>"><?= e($r['title']) ?></a>
    </h3>
    <p class="card-authors"><?= e($r['researchers'] ?? 'Researchers not recorded') ?></p>
    <p class="card-abstract"><?= e(excerpt($r['abstract'])) ?></p>
    <div class="card-foot">
        <a class="card-link" href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>">View details &rarr;</a>
        <?php if (!empty($r['has_file'])): ?>
            <span class="doc-flag" title="Full manuscript requires an active Research Access plan">Manuscript</span>
        <?php endif; ?>
    </div>
</article>
