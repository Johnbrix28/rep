<?php
/**
 * SMTP settings for sending verification codes (PHPMailer + Gmail).
 *
 * 1. Turn on 2-Step Verification on the Gmail account.
 * 2. Google Account > Security > App passwords > create one (16 characters).
 * 3. Put the Gmail address and the app password below (no spaces).
 *
 * This folder is protected by config/.htaccess, so the file is not web-readable.
 */
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'jgantala911@gmail.com');
define('MAIL_PASSWORD', 'xgwrujaxtkjskhiq');
define('MAIL_ENCRYPTION', 'tls');                     // 'tls' = STARTTLS on port 587
define('MAIL_FROM_ADDRESS', MAIL_USERNAME);
define('MAIL_FROM_NAME', 'Study Vault');

// Troubleshooting only (leave false normally).
define('MAIL_SMTP_DEBUG', false);        // true = write SMTP conversation to the PHP error log
define('MAIL_DEV_LOG_CODE', false);      // true = also write the code to the PHP error log (local testing only!)
define('MAIL_ALLOW_SELF_SIGNED', false); // true only if XAMPP fails with an SSL certificate error
