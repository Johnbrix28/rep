<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_viewer();

$q        = clean_text($_GET['q'] ?? '');
$category = valid_id($_GET['category'] ?? null);
$year     = filter_var($_GET['year'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1990, 'max_range' => 2100]]);
$page     = max(1, (int) ($_GET['page'] ?? 1));

// Only APPROVED research is ever listed here.
$where  = ["r.status = 'approved'"];
$params = [];

if ($q !== '') {
    $where[] = '(r.title LIKE :q1 OR r.abstract LIKE :q2 OR r.keywords LIKE :q3 OR c.category_name LIKE :q4
                 OR CAST(r.year AS CHAR) = :q5
                 OR EXISTS(SELECT 1 FROM research_authors ra JOIN authors a ON a.author_id=ra.author_id
                            WHERE ra.research_id=r.research_id AND a.full_name LIKE :q6))';
    $like = '%' . $q . '%';
    $params += [':q1' => $like, ':q2' => $like, ':q3' => $like, ':q4' => $like, ':q5' => $q, ':q6' => $like];
}
if ($category) { $where[] = 'r.category_id = :category'; $params[':category'] = $category; }
if ($year)     { $where[] = 'r.year = :year';            $params[':year']     = $year; }

$ws   = 'WHERE ' . implode(' AND ', $where);
$base = 'FROM research r JOIN categories c ON c.category_id=r.category_id';

$count = $pdo->prepare('SELECT COUNT(*) ' . $base . ' ' . $ws);
$count->execute($params);
$total      = (int) $count->fetchColumn();
$totalPages = max(1, (int) ceil($total / PER_PAGE));
$page       = min($page, $totalPages);
$offset     = ($page - 1) * PER_PAGE;

$s = $pdo->prepare("
    SELECT r.research_id, r.title, r.abstract, r.year, r.published_date, r.keywords,
           (r.file_path IS NOT NULL AND r.file_path <> '') AS has_file,
           c.category_name,
           (SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
              FROM research_authors ra JOIN authors a ON a.author_id = ra.author_id
             WHERE ra.research_id = r.research_id) researchers
    $base $ws
    ORDER BY r.published_date DESC, r.research_id DESC
    LIMIT " . (int) PER_PAGE . ' OFFSET ' . (int) $offset);
$s->execute($params);
$rows = $s->fetchAll();

$cats     = get_categories($pdo);
$years    = get_research_years($pdo);
$filtered = ($q !== '' || $category || $year);

$pageTitle = 'Research';
require __DIR__ . '/includes/header.php';
?>

<div class="container section">
    <a class="back-link" href="<?= BASE_URL ?>index.php">&larr; Back to home</a>

    <header class="page-head">
        <p class="eyebrow">Research archive</p>
        <h1>Search research</h1>
        <p>Approved Information Technology research. Abstracts are free to read.</p>
    </header>

    <form class="filter-panel live-search-form" method="get" autocomplete="off">
        <div class="row g-3">
            <div class="col-12">
                <label class="form-label" for="q">Search</label>
                <div class="suggest-wrap">
                    <input class="form-control live-search" id="q" name="q" value="<?= e($q) ?>" placeholder="Title, abstract, author, keyword, category or year" data-suggest-url="<?= BASE_URL ?>suggestions.php">
                    <div class="suggestions" hidden></div>
                </div>
            </div>
            <div class="col-6 col-lg-4">
                <label class="form-label" for="category">Category</label>
                <select class="form-select" id="category" name="category">
                    <option value="">All categories</option>
                    <?php foreach ($cats as $c): ?>
                        <option value="<?= (int) $c['category_id'] ?>" <?= $category === (int) $c['category_id'] ? 'selected' : '' ?>><?= e($c['category_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-6 col-lg-4">
                <label class="form-label" for="year">Year</label>
                <select class="form-select" id="year" name="year">
                    <option value="">All years</option>
                    <?php foreach ($years as $y): ?>
                        <option value="<?= (int) $y ?>" <?= $year === (int) $y ? 'selected' : '' ?>><?= (int) $y ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="filter-actions">
            <span class="result-count"><?= $total ?> research record<?= $total === 1 ? '' : 's' ?> found</span>
            <div class="d-flex gap-2">
                <?php if ($filtered): ?><a class="btn btn-outline-secondary" href="<?= BASE_URL ?>research.php">Clear</a><?php endif; ?>
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </div>
    </form>

    <?php if (!$rows): ?>
        <div class="empty-state">
            <h2>No research found</h2>
            <p>Try a different title, abstract, author, keyword, category or year.</p>
        </div>
    <?php else: ?>
        <div class="row g-3">
            <?php foreach ($rows as $r): ?>
                <div class="col-md-6 col-lg-4"><?php include __DIR__ . '/includes/research-card.php'; ?></div>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
            <nav class="pagination-nav" aria-label="Research pages">
                <ul class="pagination">
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="<?= e(query_url(['page' => $page - 1])) ?>">Previous</a></li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>"><a class="page-link" href="<?= e(query_url(['page' => $i])) ?>"><?= $i ?></a></li>
                    <?php endfor; ?>
                    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="<?= e(query_url(['page' => $page + 1])) ?>">Next</a></li>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
