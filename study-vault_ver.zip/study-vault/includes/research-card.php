<?php
/** Renders one approved research entry. Expects $r (category_name, researchers, etc.). */
$searchQuery = isset($q) ? (string) $q : '';
?>
<article class="research-card">
    <div class="card-meta">
        <span class="card-category"><?= highlight_search((string) $r['category_name'], $searchQuery) ?></span>
        <span class="card-year"><?= highlight_search((string) $r['year'], $searchQuery) ?></span>
    </div>
    <h3 class="card-title">
        <a href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>"><?= highlight_search((string) $r['title'], $searchQuery) ?></a>
    </h3>
    <p class="card-authors"><span aria-hidden="true">By</span> <?= highlight_search((string) ($r['researchers'] ?? 'Researchers not recorded'), $searchQuery) ?></p>
    <?php if ($searchQuery !== '' && !empty($r['keywords'])): ?>
        <p class="card-keywords"><?= highlight_search((string) $r['keywords'], $searchQuery) ?></p>
    <?php endif; ?>
    <p class="card-abstract"><?= highlight_search(excerpt($r['abstract']), $searchQuery) ?></p>
    <div class="card-foot">
        <a class="card-link" href="<?= BASE_URL ?>research-details.php?id=<?= (int) $r['research_id'] ?>">Read abstract <span aria-hidden="true">&rarr;</span></a>
        <?php if (!empty($r['has_file'])): ?>
            <span class="doc-flag" title="Full manuscript requires an active Research Access plan"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg> Manuscript</span>
        <?php endif; ?>
    </div>
</article>
